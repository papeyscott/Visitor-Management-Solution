 <footer class="footer text-center"> 2019 &copy; GreenLand Educational Services </footer>
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="styles/plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="styles/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="styles/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="styles/js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="styles/js/waves.js"></script>
    <!--Counter js -->
    <script src="styles/plugins/bower_components/waypoints/lib/jquery.waypoints.js"></script>
    <script src="styles/plugins/bower_components/counterup/jquery.counterup.min.js"></script>
    <!-- chartist chart -->
    <script src="styles/plugins/bower_components/chartist-js/dist/chartist.min.js"></script>
    <script src="styles/plugins/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <!-- Sparkline chart JavaScript -->
    <script src="styles/plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="styles/js/custom.min.js"></script>
    <script src="styles/js/dashboard1.js"></script>
    <script src="styles/plugins/bower_components/toast-master/js/jquery.toast.js"></script>
</body>

</html>
